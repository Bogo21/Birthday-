# Happy Birthday Ayush

Static site: open index.html, or enable GitHub Pages (Settings > Pages > Deploy from branch > main / root).

Note: Nut uses a simple built-in brain here. His AI replies and cross-device saving only work inside Claude.
